//
//  Case1ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/22.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case1ViewController.h"

@interface Case1ViewController ()
@property (nonatomic,strong) UILabel * titleLab;
@property (nonatomic,strong) UILabel * yellowLab;
@property (nonatomic,strong) UILabel * greenLab;
@property (nonatomic,strong) UIView  * contentView;
@property (nonatomic,strong) UIStepper * leftSetpper;
@property (nonatomic,strong) UIStepper * rightSetpper;
@end

@implementation Case1ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
}

//初始化UI
- (void)initUI{
    //创建UI
    self.titleLab = [self getNewLabel];
    self.yellowLab = [self getNewLabel];
    self.greenLab = [self getNewLabel];
    self.contentView = [self getNewView];
    self.leftSetpper = [self getNewStepper];
    self.rightSetpper = [self getNewStepper];
    
    //添加
    [self.view addSubview:self.titleLab];
    [self.contentView addSubview:self.yellowLab];
    [self.contentView addSubview:self.greenLab];
    [self.view addSubview:self.contentView];
    [self.view addSubview:self.leftSetpper];
    [self.view addSubview:self.rightSetpper];
    
    
    //布局
    self.titleLab.numberOfLines = 0;
    [self.titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        //距离父控件左边20
        make.left.mas_equalTo(20);
        //距离父控件日边间隔20
        make.right.mas_equalTo(-20);
        //距离父控件上面84，其实也是20，因为导航栏占了64
        make.top.mas_equalTo(84);
    }];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        //设置距离标题控件的顶部距离20个像素
        make.top.mas_equalTo(_titleLab.mas_bottom).with.offset(20);
        //左边右边和父控件一直
        make.left.right.mas_equalTo(_titleLab);
        //设置高度
        make.height.mas_equalTo(50);
    }];
    
    [self.yellowLab mas_makeConstraints:^(MASConstraintMaker *make) {
        //设置顶部距离父控件5个像素
//        make.top.equalTo(_contentView.mas_top).with.offset(5);
//        make.top.mas_equalTo(5);
        //设置左边距离父控件5个像素
//        make.left.equalTo(_contentView.mas_left).with.offset(5);
//        make.left.mas_equalTo(5);
        
        //设置顶部、左边距离父控件5个像素
        make.left.top.mas_equalTo(5);
        
        // 40高度
        make.height.equalTo(@40);
    }];
    
    [self.greenLab mas_makeConstraints:^(MASConstraintMaker *make) {
        //设置顶部距离父控件5个像素
//        make.top.equalTo(_contentView.mas_top).with.offset(5);
//        make.top.equalTo(_yellowLab);
        make.top.equalTo(@5);
        
        //设置左边等于yellowLabel的右边界 +2 个像素
        make.left.equalTo(_yellowLab.mas_right).with.offset(2);
        
        // 40高度
        make.height.equalTo(@40);
        
        //设置右边小于或者等于父控件的右边界 -2个像素
        make.right.lessThanOrEqualTo(_contentView.mas_right).with.offset(-2);
    }];
    
    //设置内容约束
    /*
     1、优先级
        UILayoutPriorityRequired            1000    默认
        UILayoutPriorityDefaultHigh         750
        UILayoutPriorityDefaultLow          250
        UILayoutPriorityFittingSizeLevel    50 基本上就不进行运算的级别
     2、方向
        UILayoutConstraintAxisHorizontal    0   水平方法
        UILayoutConstraintAxisVertical      1   垂直方向
     */
    
    /*
     Content Hugging = 抱紧！
     
        这个属性的优先级越高，整个View就要越“抱紧”View里面的内容。也就是View的大小不会随着父级View的扩大而扩大。
     
     ********************************
     
     Content Compression Resistance = 不许挤我！
     
        对，这个属性说白了就是“不许挤我”=。=
        这个属性的优先级（Priority）越高，越不“容易”被压缩。也就是说，当整体的空间装不下所有的View的时候，Content Compression Resistance优先级越高的，显示的内容越完整。
     */
    [self.yellowLab setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [self.yellowLab setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    
    [self.greenLab setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [self.greenLab setContentCompressionResistancePriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisHorizontal];
    
    [self.leftSetpper mas_makeConstraints:^(MASConstraintMaker *make) {
        
        //设置左边约束
        make.left.equalTo(_contentView.mas_left).with.offset(10);
        //设置头部约束
        make.top.equalTo(_yellowLab.mas_bottom).with.offset(30);
    }];

    [self.rightSetpper mas_makeConstraints:^(MASConstraintMaker *make) {
        //设置右边等于greenLabel的右边 -10 个像素
        make.right.equalTo(_contentView.mas_right).with.offset(-10);
        
        //设置头部约束
//        make.top.equalTo(_greenLab.mas_bottom).with.offset(20);//方法一
        make.top.equalTo(_leftSetpper);//方法二
    }];
    
    self.contentView.backgroundColor = [UIColor lightGrayColor];
    self.titleLab.text = @"并排两个label，整体靠右边，宽度随内容增长，左边label“优先级更高”。";
    self.yellowLab.text = @"Label";
    self.greenLab.text = @"Label";
    
    self.yellowLab.backgroundColor = [UIColor yellowColor];
    self.greenLab.backgroundColor = [UIColor greenColor];
    
    [self addTargetForStepper:self.leftSetpper tag:1];
    [self addTargetForStepper:self.rightSetpper tag:2];
    
}

- (void)addTargetForStepper:(UIStepper *)stepper tag:(NSInteger)tag{
    stepper.tag = tag;
    [stepper addTarget:self action:@selector(stepperValueChange:) forControlEvents:UIControlEventValueChanged];
    stepper.value = 1;
    stepper.minimumValue = 0;
    stepper.maximumValue = 10;
    stepper.stepValue = 1;
}

- (void)stepperValueChange:(UIStepper *)stepper{
    if (stepper.tag == 1) {
        self.yellowLab.text = [self strWithCount:stepper.value];
    }else{
        self.greenLab.text = [self strWithCount:stepper.value];
    }
}

- (NSString *)strWithCount:(NSInteger)count{
    NSMutableString * mStr = [NSMutableString string];
    
    for (NSInteger i = 0; i<count; i++) {
        [mStr appendString:@"Label；"];
    }
    return mStr;
}




@end
