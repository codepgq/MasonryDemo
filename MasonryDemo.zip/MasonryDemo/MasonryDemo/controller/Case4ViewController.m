//
//  Case4ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case4ViewController.h"
#import "Case4.h"
#import "Case4TableViewCell.h"
@interface Case4ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UILabel * titleLab;
@property (nonatomic,strong) UITableView * tableView;
@property (nonatomic,strong) NSArray <Case4*>* datas;
@end

@implementation Case4ViewController

static NSString * const Case4CellIdentifier = @"Case4CellIdentifier";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.datas = [Case4 randomDataWithCount:100];
    
    [self initUI];
}

- (void)initUI{
    self.titleLab = [UILabel new];
    self.tableView = [UITableView new];
    
    //add
    [self.view addSubview:self.titleLab];
    [self.view addSubview:self.tableView];
    
    //设置约束
    //title label
    [self.titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        //上
        make.top.equalTo(@84);
        //左
        make.left.equalTo(@20);
        //右
        make.right.equalTo(@-20);
    }];
    //tableview
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        //上、下、左、右 0
        make.top.equalTo(_titleLab.mas_bottom).offset(5);
        make.left.right.bottom.equalTo(self.view);
    }];
    
    self.titleLab.text = @"变高的Cell+简单的高度缓存\n方法1：调用systemLayoutSizeFittingSize：获取高度\n方法2：使用IOS8的Self-Sizing特性";
    self.titleLab.numberOfLines = 0;
    self.tableView.backgroundColor = [UIColor orangeColor];
    //register cell
    [self.tableView registerClass:[Case4TableViewCell class] forCellReuseIdentifier:Case4CellIdentifier];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    self.tableView.rowHeight = 60;
    
    if (SYSTEM_VERSION_8_0) { //自动计算
        self.tableView.estimatedRowHeight = 100;
        self.tableView.rowHeight = UITableViewAutomaticDimension;
    }
    
}

#pragma MARK - TalbeView DataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.datas.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (SYSTEM_VERSION_8_0) {//自动计算
        return UITableViewAutomaticDimension;
    }
    else{//自己计算
    
        Case4 * tempCase = self.datas[indexPath.row];
        if (tempCase.rowHeight > 0) {
            //
            NSLog(@"缓存得到高度");
            return tempCase.rowHeight;
        }
        
        //1、获取cell
        Case4TableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:Case4CellIdentifier];
        
        //2、设置数据 3、得到高度
        [tempCase updateRowHeight:[cell getRowHeightWithCase4:self.datas[indexPath.row]]];
        
        //保存
        self.datas[indexPath.row].rowHeight = tempCase.rowHeight;
        
        
        NSLog(@"计算高度");
        return tempCase.rowHeight;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Case4TableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:Case4CellIdentifier forIndexPath:indexPath];
    [cell updateCellWithCase4:self.datas[indexPath.row]];
    return cell;
}

@end
