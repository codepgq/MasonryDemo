//
//  Case5ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case5ViewController.h"

//#define NEW_FEATURE
//如果注释掉上面的宏就是使用length值做约束，否则就使用心得方法mas_top/bottomLayoutGuide做约束

@interface Case5ViewController ()
@property (nonatomic,strong) UIView * greenView;
@property (nonatomic,strong) UIView * yellowView;
@property (nonatomic,strong) UILabel * title1;
@property (nonatomic,strong) UILabel * title2;
@property (nonatomic,strong) UILabel * title3;
@property (nonatomic,strong) UIButton * button1;
@property (nonatomic,strong) UIButton * button2;
@property (nonatomic,strong) UIButton * button3;

@end

@implementation Case5ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
    
    NSLog(@"%s top - length : %g",__func__,[self.topLayoutGuide length]);
}

- (void)initUI{
    //create
    _greenView = [UIView new];
    _yellowView = [UIView new];
    _title1 = [UILabel new];
    _title2 = [UILabel new];
    _title3 = [UILabel new];
    _button1 = [UIButton new];
    _button2 = [UIButton new];
    _button3 = [UIButton new];
    
    //add
    [self addViews:@[_greenView,_yellowView,_title3,_title2,_title1,_button3,_button2,_button1] father:self.view];
    
    //set contrasint
    [_greenView mas_makeConstraints:^(MASConstraintMaker *make) {
#ifndef NEW_FEATURE
        //上约束
        make.top.equalTo(self.mas_topLayoutGuide);
#endif
        make.left.right.equalTo(self.view);
        make.height.equalTo(@44);
    }];
    [_yellowView mas_makeConstraints:^(MASConstraintMaker *make) {
#ifndef NEW_FEATURE
        make.bottom.equalTo(self.mas_bottomLayoutGuide);
#endif
        make.right.equalTo(self.view);
        make.left.equalTo(self.view);
        make.height.equalTo(@44);
    }];
    [_title1 mas_makeConstraints:^(MASConstraintMaker *make) {
        //居中
        make.centerX.equalTo(self.view.mas_centerX);
        //顶部约束
        make.top.equalTo(_greenView.mas_bottom).offset(50);
        make.left.equalTo(self.view.mas_left).offset(40);
        make.right.equalTo(self.view.mas_right).offset(-40);
    }];
    [_title2 mas_makeConstraints:^(MASConstraintMaker *make) {
        //居中
        make.centerX.equalTo(self.view.mas_centerX);
        //顶部约束
        make.top.equalTo(_title1.mas_bottom).offset(15);
        make.left.equalTo(self.view.mas_left).offset(30);
        make.right.equalTo(self.view.mas_right).offset(-30);
    }];
    [_title3 mas_makeConstraints:^(MASConstraintMaker *make) {
        //居中
        make.centerX.equalTo(self.view.mas_centerX);
        //顶部约束
        make.top.equalTo(_title2.mas_bottom).offset(15);
        make.left.equalTo(self.view.mas_left).offset(50);
        make.right.equalTo(self.view.mas_right).offset(-50);
    }];
    [_button1 mas_makeConstraints:^(MASConstraintMaker *make) {
        //居中
        make.centerX.equalTo(self.view.mas_centerX);
        //顶部约束
        make.top.equalTo(_title3.mas_bottom).offset(15);
        //设置左右约束
        make.left.equalTo(self.view.mas_left).offset(10);
        make.right.equalTo(self.view.mas_right).offset(-10);
    }];
    [_button2 mas_makeConstraints:^(MASConstraintMaker *make) {
        //居中
        make.centerX.equalTo(self.view.mas_centerX);
        //顶部约束
        make.top.equalTo(_button1.mas_bottom).offset(15);
        //设置左右约束
        make.left.equalTo(self.view.mas_left).offset(10);
        make.right.equalTo(self.view.mas_right).offset(-10);
    }];
    [_button3 mas_makeConstraints:^(MASConstraintMaker *make) {
        //居中
        make.centerX.equalTo(self.view.mas_centerX);
        //顶部约束
        make.top.equalTo(_button2.mas_bottom).offset(15);
        //设置左右约束
        make.left.equalTo(self.view.mas_left).offset(10);
        make.right.equalTo(self.view.mas_right).offset(-10);    }];
    
    //set ohter
    
    _greenView.backgroundColor = [UIColor greenColor];
    _yellowView.backgroundColor = [UIColor yellowColor];
    
    //label
    _title1.numberOfLines = 0;
    _title1.text = @"使用Top（Bottom）LayoutGuide确定当前ViewController的最佳显示范围。";
    _title1.textAlignment = NSTextAlignmentCenter;
    _title2.numberOfLines = 0;
    _title2.text = @"方法1：直接使用Length属性，避免强制转换成为UIView所带来的风险。";
    _title2.textAlignment = NSTextAlignmentCenter;
    _title3.numberOfLines = 0;
    _title3.text = @"方法2：使用新的mas_topLayoutGuide和mas_bottomLayoutGuide。";
    _title3.textAlignment = NSTextAlignmentCenter;
    
    //button
    [_button1 setTitle:@"显示或隐藏NavigationBar" forState:UIControlStateNormal];
    [_button1 addTarget:self action:@selector(buttonClick1) forControlEvents:UIControlEventTouchUpInside];
    [_button1 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    
    [_button2 setTitle:@"显示或者隐藏TabBar" forState:UIControlStateNormal];
    [_button2 addTarget:self action:@selector(buttonClick2) forControlEvents:UIControlEventTouchUpInside];
    [_button2 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    
    [_button3 setTitle:@"返回" forState:UIControlStateNormal];
    [_button3 addTarget:self action:@selector(buttonClick3) forControlEvents:UIControlEventTouchUpInside];
    [_button3 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
}


- (void)buttonClick1{
    [self.navigationController setNavigationBarHidden:!self.navigationController.navigationBarHidden animated:NO];
    [self updateViewConstraints];
    
}
- (void)buttonClick2{
    [self.navigationController setToolbarHidden:!self.navigationController.toolbarHidden animated:NO];
    [self updateViewConstraints];
}
- (void)buttonClick3{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self.navigationController setToolbarHidden:YES animated:NO];
}

- (void)updateViewConstraints{
    
#ifndef NEW_FEATURE
    [_greenView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).with.offset(self.topLayoutGuide.length);
    }];
    

    [_yellowView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view.mas_bottom).with.offset(-self.bottomLayoutGuide.length);
    }];
#endif
    [super updateViewConstraints];
}

@end
