//
//  Case11ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case11ViewController.h"

@interface Case11ViewController ()
@property (nonatomic,strong) MASConstraint *tipLabelLeft;
@property (nonatomic,strong) MASConstraint *tipLabelTop;
@property (nonatomic,strong) UILabel *tipLabel;
@property (nonatomic,strong) UILabel *bindingLab;
@property (nonatomic,strong) UIView * contentView;
@end

@implementation Case11ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
    
}

- (void)initUI{
    //create
    _contentView = [UIView new];
    _tipLabel = [UILabel new];
    _bindingLab = [UILabel new];
    
    [self.view addSubview:_contentView];
    [_contentView addSubview:_tipLabel];
    [_contentView addSubview:_bindingLab];
    
    //set property
    _contentView.layer.borderColor = [UIColor redColor].CGColor;
    _contentView.layer.borderWidth = 2;
    _tipLabel.backgroundColor = [UIColor cyanColor];
    _tipLabel.text = @"拖拽我";
    _tipLabel.adjustsFontSizeToFitWidth = YES;
    _bindingLab.text = @"我就跟着大哥走";
    _bindingLab.font = [UIFont systemFontOfSize:13];
    
//    [_bindingLab setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
//    [_bindingLab setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    [_bindingLab setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [_bindingLab setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    
    [_bindingLab sizeToFit];
    
    // add pan gesture
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(tipLabelPanEvent:)];
    _tipLabel.userInteractionEnabled = YES;
    [_contentView addGestureRecognizer:pan];
    
    
    __weak typeof(self)weakSelf = self;
    [_contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.view).offset(5);
        make.top.equalTo(weakSelf.mas_topLayoutGuide).offset(5);
        make.right.equalTo(weakSelf.view.mas_right).offset(-5);
        make.height.equalTo(weakSelf.view.mas_height).multipliedBy(0.5);
    }];
    
    [_tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.greaterThanOrEqualTo(_contentView.mas_left);
        make.top.greaterThanOrEqualTo(_contentView.mas_top);
        make.right.lessThanOrEqualTo(_contentView.mas_right);
        make.bottom.lessThanOrEqualTo(_contentView.mas_bottom);
        
        //设置left 和top 的约束优先级为750
        _tipLabelLeft = make.centerX.equalTo(_contentView.mas_left).offset(50).priorityHigh(); // 优先级要比边界条件低
        _tipLabelTop =  make.centerY.equalTo(_contentView.mas_top).offset(50).priorityHigh();
        
        make.width.equalTo(@60);
        make.height.equalTo(@35);
        
    }];
    
    [_bindingLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(_tipLabel.mas_top).offset(-10).priorityHigh();
        make.left.equalTo(_tipLabel.mas_left).offset(10).priorityHigh();
        
        make.left.greaterThanOrEqualTo(_contentView.mas_left);
        make.top.greaterThanOrEqualTo(_contentView.mas_top);
        make.right.lessThanOrEqualTo(_contentView.mas_right);
        make.bottom.lessThanOrEqualTo(_contentView.mas_bottom);
    }];
}

- (void)dealloc{
    NSLog(@"%s",__func__);
}

- (void)tipLabelPanEvent:(UIPanGestureRecognizer *)pan{
    CGPoint toucePoint = [pan locationInView:self.contentView];
    _tipLabel.text = NSStringFromCGPoint(toucePoint);
    
    _tipLabelTop.offset = toucePoint.y;
    _tipLabelLeft.offset = toucePoint.x;
}

@end
