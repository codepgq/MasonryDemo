//
//  Case8ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case8ViewController.h"
#import "Case8TableViewCell.h"
#import "Case4TableViewCell.h"
#import "Case8.h"
@interface Case8ViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView * tableView;
@property (nonatomic,strong) NSArray<Case8*> * datas;
@property (nonatomic,strong) Case8TableViewCell * tempCell;
@end


NSString * const Case8CellIdentifer = @"Case8CellIdentifer";
@implementation Case8ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _datas = [Case8 randomDataWithCount:20];
    
    [self initUI];
}

- (void)initUI{
    self.tableView = [UITableView new];
    [self.view addSubview:self.tableView];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self.view);
        make.top.equalTo(self.mas_topLayoutGuide);
    }];
    
    [self.tableView registerClass:[Case8TableViewCell class] forCellReuseIdentifier:Case8CellIdentifer];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _datas.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{//自己计算
    
    Case8 * tempCase = self.datas[indexPath.row];
    if (tempCase.rowHeight > 0) {
        //
        NSLog(@"缓存得到高度");
        return tempCase.rowHeight;
    }
    
    //1、获取cell
    if (!self.tempCell) {
        self.tempCell = [tableView dequeueReusableCellWithIdentifier:Case8CellIdentifer];
    }
    
    //2、设置数据 3、得到高度
    [tempCase updateRowHeight:[self.tempCell getRowHeightWithCase4:self.datas[indexPath.row]]];
    
    //保存
    self.datas[indexPath.row].rowHeight = tempCase.rowHeight;
    
    
    NSLog(@"计算高度");
    return tempCase.rowHeight;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Case8TableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:Case8CellIdentifer forIndexPath:indexPath];
    
    [cell updateCellWithCase4:_datas[indexPath.row]];
    __weak typeof(self) weakSelf = self;
    [cell showMoreButton:^(UIButton *button,Case8 * case8) {
        
        
        weakSelf.datas[case8.index].rowHeight = 0;
        weakSelf.datas[case8.index].isShow = case8.isShow;
        
        
        [weakSelf.tableView beginUpdates];
        [weakSelf.tableView endUpdates];
        NSIndexPath * index = [NSIndexPath indexPathForRow:case8.index inSection:0];
//        [tableView reloadRowsAtIndexPaths:@[index] withRowAnimation:UITableViewRowAnimationFade];
        
        // 让展开/收回的Cell居中，酌情加，看效果决定
//        [_tableView scrollToRowAtIndexPath:index atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }];
    
    return cell;
}

@end
