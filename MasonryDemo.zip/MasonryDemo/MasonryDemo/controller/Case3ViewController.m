//
//  Case3ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/22.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case3ViewController.h"

@interface Case3ViewController ()

@property (nonatomic,strong) UIView *contentView;
@property (nonatomic,strong) UIView *subView;
@property (nonatomic,strong) UISlider * slider;

@property (nonatomic,strong) MASConstraint * constraint;
@end

@implementation Case3ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
}

- (void)initUI{
    //创建
    self.contentView = [UIView new];
    self.subView = [UIView new];
    self.slider =  [UISlider new];
    
    //添加
    [self.view addSubview:self.contentView];
    [self.view addSubview:self.slider];
    [self.contentView addSubview:self.subView];
    
    
    //布局
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        //设置高度
        make.height.equalTo(@50);
        //居中
        make.left.equalTo(@20);
        self.constraint = make.right.equalTo(@-20);
        
        //距离顶部距离
        make.top.equalTo(self.view.mas_top).offset(200);
    }];
    
    [self.slider mas_makeConstraints:^(MASConstraintMaker *make) {
        //设置顶部约束
        make.top.equalTo(self.contentView.mas_top).offset(50);
        
        make.left.equalTo(@20);
        make.right.equalTo(@(-20));
        make.height.equalTo(@44);
    }];
    
    
    [self.subView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left);
        make.top.equalTo(self.contentView.mas_top);
        make.bottom.equalTo(self.contentView.mas_bottom);
        make.width.equalTo(self.contentView.mas_width).multipliedBy(0.5);
    }];
    
    self.contentView.backgroundColor = [UIColor grayColor];
    self.subView.backgroundColor = [UIColor cyanColor];
    
    [self.slider addTarget:self action:@selector(sliderMove:) forControlEvents:UIControlEventValueChanged];
    self.slider.minimumValue = 0.1;
    self.slider.maximumValue = 1;
    [self.slider setValue:1];
}

- (void)sliderMove:(UISlider *)slider{
    self.constraint.mas_equalTo(-1 * ((1 - slider.value) * SC_Width - 20));
}
@end
