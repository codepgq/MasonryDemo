//
//  Case13ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case13ViewController.h"
#import "Case13TableViewCell.h"
#import "Case13.h"
@interface Case13ViewController ()<UITableViewDataSource>

@property (nonatomic,strong) UITableView * tableView;
@property (nonatomic,strong) NSArray <Case13*>* datas;

@end

NSString * const Case13CellIdentifier = @"Case13CellIdentifier";

@implementation Case13ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    _tableView = [UITableView new];
    
    [self.view addSubview:_tableView];
    
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(self.mas_topLayoutGuide);
    }];
    _tableView.backgroundColor = [UIColor redColor];
    _tableView.dataSource = self;
    _tableView.rowHeight = UITableViewAutomaticDimension;
    _tableView.estimatedRowHeight = 80;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    _datas = [Case13 randomDataWithCount:20];
    [_tableView registerClass:[Case13TableViewCell class] forCellReuseIdentifier:Case13CellIdentifier];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _datas.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Case13TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Case13CellIdentifier forIndexPath:indexPath];
    
    [cell setLabelWith:_datas[indexPath.row]];
    
    return cell;
}

@end
