//
//  Case9ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case9ViewController.h"

#define ITEM_COUNT 4

@interface Case9ViewController ()

@property (nonatomic,strong) UILabel * titleLab;
@property (nonatomic,strong) UIView * contentOne;
@property (nonatomic,strong) UIView * contentTwo;
@property (nonatomic,strong) UISlider * slider;

@property (nonatomic,strong) MASConstraint *contentOneWidthCons;
@property (nonatomic,strong) MASConstraint *contentTwoWidthCons;

@end

@implementation Case9ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
    
    [self initContainer1];
    [self initContiner2];
}

- (void)initUI{
    _titleLab = [UILabel new];
    _contentOne = [UIView new];
    _contentTwo = [UIView new];
    _slider = [UISlider new];
    
    [self addViews:@[_titleLab,_contentTwo,_contentOne,_slider] father:self.view];
    
    [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.top.equalTo(self.mas_topLayoutGuide).offset(20);
    }];
    
    __block UIView * lasetView = _titleLab;
    __block NSInteger i = 0;
    __block MASConstraint * contraint;
    for (UIView * view in @[_contentOne,_contentTwo,_slider]) {
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lasetView.mas_bottom).offset(20);
            make.left.equalTo(self.view.mas_left).offset(20);
            contraint = make.width.equalTo(@300);
            if (i==0) {
                _contentOneWidthCons = contraint;
            }
            if (i == 1) {
                _contentTwoWidthCons = contraint;
            }
            make.height.equalTo(@60);
            lasetView = view;
            
            i++;
        }];
    }
    
    _titleLab.text = @"两种实现等距的方法：\n1.增加宽度的SpaceView\n2.直接按比例设置multiplier";
    _titleLab.numberOfLines = 0;
    _titleLab.textAlignment = NSTextAlignmentCenter;
    _contentTwo.backgroundColor = [UIColor redColor];
    _contentOne.backgroundColor = [UIColor lightGrayColor];
    _contentOne.clipsToBounds = YES;
    [_slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    _slider.value = 1;
}

- (void)initContainer1{
    UIView *lastSpaceView = [UIView new];
    lastSpaceView.backgroundColor = [UIColor greenColor];
    [_contentOne addSubview:lastSpaceView];
    
    [lastSpaceView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.equalTo(_contentOne);
    }];
    
    for (NSInteger i = 0; i < ITEM_COUNT; i++) {
        //创建显示的view
        UIView * itemView = [self getItemView];
        [_contentOne addSubview:itemView];
        
        [itemView mas_makeConstraints:^(MASConstraintMaker *make) {
            // ************    设置宽高的时候需要 先width 在height     **********
            make.width.height.equalTo(@60);
            make.left.equalTo(lastSpaceView.mas_right);
            make.centerY.equalTo(_contentOne.mas_centerY);
        }];
        
        UIView * spaceView = [UIView new];
        spaceView.backgroundColor = [UIColor greenColor];
        [_contentOne addSubview:spaceView];
        [spaceView mas_makeConstraints:^(MASConstraintMaker *make) {
            //降低优先级，可以被压缩
            make.left.equalTo(itemView.mas_right).with.priorityHigh();
            make.top.bottom.equalTo(_contentOne);
            make.width.equalTo(lastSpaceView.mas_width);
        }];
        lastSpaceView = spaceView;
    }
    
    //最后添加占位
    [lastSpaceView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_contentOne.mas_right);
    }];
    
}

- (void)initContiner2{
    for (NSInteger i = 0; i < ITEM_COUNT; i++) {
        UIView * itemView = [self getItemView];
        [_contentTwo addSubview:itemView];
        
        [itemView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.equalTo(@60);
            make.centerY.equalTo(_contentTwo.mas_centerY);
            make.centerX.equalTo(_contentTwo.mas_right).multipliedBy(((CGFloat) i + 1) / ((CGFloat)ITEM_COUNT + 1));
        }];
    }
}

- (UIView *)getItemView{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"emoitcon"]];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    return imageView;
}
                             


- (void)sliderValueChanged:(UISlider *)slider{
    if (_contentTwoWidthCons) {
        
        _contentTwoWidthCons.equalTo(@(slider.value * 300));
    }
    if (_contentOneWidthCons) {
        
        _contentOneWidthCons.equalTo(@(slider.value * 300));
    }
}

@end
