//
//  Case6ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case6ViewController.h"
#import "Case6ItemView.h"
@interface Case6ViewController ()

@end

@implementation Case6ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
}

- (void)initUI{
    Case6ItemView * item1 = [Case6ItemView itemWithImage:[UIImage imageNamed:@"dog_small"] text:@"太美的承诺应为太年轻"];
    Case6ItemView * item2 = [Case6ItemView itemWithImage:[UIImage imageNamed:@"dog_middle"] text:@"但亲爱的那不是爱情"];
    Case6ItemView * item3 = [Case6ItemView itemWithImage:[UIImage imageNamed:@"dog_big"] text:@"一切都变得太透明了"];
    
    [self addViews:@[item1,item2,item3] father:self.view];
    
    [item1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view.mas_left).with.offset(8);
        make.top.mas_equalTo(self.view.mas_top).with.offset(200);
    }];
    
    // 跟第一个item的baseline对其
    [item2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(item1.mas_right).with.offset(10);
        make.baseline.mas_equalTo(item1.mas_baseline);
    }];
    
    // 跟第一个item的baseline对其
    [item3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(item2.mas_right).with.offset(10);
        make.baseline.mas_equalTo(item1.mas_baseline);
    }];
}

@end
