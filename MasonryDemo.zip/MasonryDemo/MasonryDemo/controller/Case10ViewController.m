//
//  Case10ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case10ViewController.h"

@interface Case10ViewController ()
@property (nonatomic,strong) MASConstraint *tipLabelLeft;
@property (nonatomic,strong) MASConstraint *tipLabelTop;
@property (nonatomic,strong) UILabel *tipLabel;
@property (nonatomic,strong) UIView * contentView;
@end

@implementation Case10ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
    
}

- (void)initUI{
    //create
    _contentView = [UIView new];
    _tipLabel = [UILabel new];
    
    [self.view addSubview:_contentView];
    [_contentView addSubview:_tipLabel];
    
    //set property
    _contentView.layer.borderColor = [UIColor redColor].CGColor;
    _contentView.layer.borderWidth = 2;
    _tipLabel.backgroundColor = [UIColor cyanColor];
    _tipLabel.text = @"拖拽我";
    _tipLabel.adjustsFontSizeToFitWidth = YES;
    
    // add pan gesture
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(tipLabelPanEvent:)];
    _tipLabel.userInteractionEnabled = YES;
    [_tipLabel addGestureRecognizer:pan];
    
    
    __weak typeof(self)weakSelf = self;
    [_contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.view).offset(5);
        make.top.equalTo(weakSelf.mas_topLayoutGuide).offset(5);
        make.right.equalTo(weakSelf.view.mas_right).offset(-5);
        make.height.equalTo(weakSelf.view.mas_height).multipliedBy(0.5);
    }];
    
    [_tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.greaterThanOrEqualTo(_contentView.mas_left);
        make.top.greaterThanOrEqualTo(_contentView.mas_top);
        make.right.lessThanOrEqualTo(_contentView.mas_right);
        make.bottom.lessThanOrEqualTo(_contentView.mas_bottom);
        
        //设置left 和top 的约束优先级为750
        _tipLabelLeft = make.centerX.equalTo(_contentView.mas_left).offset(50).priorityHigh(); // 优先级要比边界条件低
        _tipLabelTop =  make.centerY.equalTo(_contentView.mas_top).offset(50).priorityHigh();
        
        make.width.equalTo(@60);
        make.height.equalTo(@35);
        
    }];
}

- (void)dealloc{
    NSLog(@"%s",__func__);
}

- (void)tipLabelPanEvent:(UIPanGestureRecognizer *)pan{
    CGPoint toucePoint = [pan locationInView:self.contentView];
    _tipLabel.text = NSStringFromCGPoint(toucePoint);
    
    _tipLabelTop.offset = toucePoint.y;
    _tipLabelLeft.offset = toucePoint.x;
}
@end
