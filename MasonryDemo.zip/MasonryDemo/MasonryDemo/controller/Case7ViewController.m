//
//  Case7ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case7ViewController.h"
#define PARALLAXHEADERHEIGHT 235
@interface Case7ViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) UIImageView * parallaxHeader;
@end

@implementation Case7ViewController{
    MASConstraint *_parallaxHeaderHeight;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI{
    self.tableView = [[UITableView alloc] init];
    _parallaxHeader = [UIImageView new];
    
    [self.view addSubview:self.tableView];
    [self.view insertSubview:_parallaxHeader belowSubview:_tableView];
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.contentInset = UIEdgeInsetsMake(PARALLAXHEADERHEIGHT, 0, 0, 0);
    // KVO
    [self.tableView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    
    _parallaxHeader.image = [UIImage imageNamed:@"parallax"];
    _parallaxHeader.contentMode = UIViewContentModeScaleAspectFill;
    
    [_parallaxHeader mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.top.equalTo(self.mas_topLayoutGuide);
        _parallaxHeaderHeight = make.height.mas_equalTo(PARALLAXHEADERHEIGHT);
    }];
    
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(self.mas_topLayoutGuide);
    }];
    
    
    
}



//- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
//    if (scrollView.contentOffset.y < 0) {
//        _parallaxHeaderHeight.equalTo(@(PARALLAXHEADERHEIGHT - scrollView.contentOffset.y));
//    }
//    else{
//        _parallaxHeaderHeight.equalTo(@(PARALLAXHEADERHEIGHT));
//    }
//}

#pragma MARK - KVO
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    if ([keyPath isEqualToString:@"contentOffset"]) {
        CGPoint contentOffset = [[change objectForKey:NSKeyValueChangeNewKey] CGPointValue];
        
        if (contentOffset.y < -PARALLAXHEADERHEIGHT) {
            _parallaxHeaderHeight.equalTo(@(-contentOffset.y));
        }
        
    }
}

- (void)dealloc{
    [self.tableView removeObserver:self forKeyPath:@"contentOffset"];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 15;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%zd",indexPath.row];
    return cell;
}

@end
