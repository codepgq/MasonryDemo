//
//  Case2ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/22.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case2ViewController.h"

@interface Case2ViewController ()

@property (nonatomic,strong) UISwitch * sw1;
@property (nonatomic,strong) UISwitch * sw2;
@property (nonatomic,strong) UISwitch * sw3;
@property (nonatomic,strong) UISwitch * sw4;

@property (nonatomic,strong) UIView *contentImg;
@property (nonatomic,strong) UIView *contentSwitch;

//保存所有的图片Imageview
@property (nonatomic,strong) NSMutableArray *imageViews;
//保存所有的ImageView的宽度约束
@property (nonatomic,strong) NSMutableArray * widthConstraints;
@end
//设定大小
#define IMAGE_SIZE 50

@implementation Case2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.imageViews = [NSMutableArray array];
    self.widthConstraints = [NSMutableArray array];
    [self initUI];
}

- (void)initUI{
    
    self.sw1 = [UISwitch new];
    self.sw2 = [UISwitch new];
    self.sw3 = [UISwitch new];
    self.sw4 = [UISwitch new];
    
    self.contentImg = [UIView new];
    self.contentSwitch = [UIView new];
    
    [self addViews:@[self.sw1,self.sw2,self.sw3,self.sw4] father:self.contentSwitch];
    [self.view addSubview:self.contentImg];
    [self.view addSubview:self.contentSwitch];
    
    [_contentImg mas_makeConstraints:^(MASConstraintMaker *make) {
        //设置高度
        make.height.equalTo(@(IMAGE_SIZE));
        //水平居中
        make.centerX.equalTo(self.view.mas_centerX);
        //距离顶部200
        make.top.equalTo(self.view.mas_top).offset(200);
    }];
    _contentImg.backgroundColor = [UIColor lightGrayColor];
    
    //循环创建、添加imageView
    for (NSUInteger i = 0; i < 4; i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"emoitcon"]];
        [_imageViews addObject:imageView];
        [_contentImg addSubview:imageView];
    }
    
    
    
    CGSize imageViewSize = CGSizeMake(IMAGE_SIZE, IMAGE_SIZE);
    
    __block UIView *laseView = nil;
    __block MASConstraint *widthConstraint = nil;
    
    NSInteger arrayCount = _imageViews.count;
    [_imageViews enumerateObjectsUsingBlock:^(UIView * view, NSUInteger idx, BOOL * _Nonnull stop) {
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            
            //宽高
            widthConstraint = make.width.equalTo(@(imageViewSize.width));
            make.height.equalTo(@(imageViewSize.height));
            
            //左边的约束
            //判断是不是第一个View，如果是第一个那么应该对其父视图的左边
            make.left.equalTo(laseView ? laseView.mas_right : view.superview.mas_left);
            make.centerY.equalTo(view.superview.mas_centerY);
            
            //如果是最后一个View，那么设置他的右边与父控制器对其
            if (idx == arrayCount - 1) {
                make.right.equalTo(view.superview.mas_right);
            }
            
            [_widthConstraints addObject:widthConstraint];
            laseView = view;
        }];
    }];
    
    
    //sw
    [self.contentSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
        //设置高度
        make.height.equalTo(@34);
        //居中显示
        make.centerX.equalTo(self.view.mas_centerX);
        //距离顶部距离
        make.top.equalTo(self.contentImg.mas_bottom).offset(50);
    }];
    
    laseView = nil;
    arrayCount = 4;
    self.contentSwitch.backgroundColor = [UIColor redColor];
    
   [@[self.sw1,self.sw2,self.sw3,self.sw4] enumerateObjectsUsingBlock:^(UIView *  view, NSUInteger idx, BOOL * _Nonnull stop) {
       view.tag = idx;
       [(UISwitch *)view setOn:YES];
       [(UISwitch *)view addTarget:self action:@selector(switchValueChange:) forControlEvents:UIControlEventValueChanged];
       [view mas_makeConstraints:^(MASConstraintMaker *make) {
           
           make.left.equalTo(laseView ? laseView.mas_right : view.superview.mas_left);
           make.centerY.equalTo(view.superview.mas_centerY);
           
           if (idx == arrayCount - 1) {
               make.right.equalTo(view.superview.mas_right);
           }
           
           laseView = view;
       }];
   }];
    
}

- (void)switchValueChange:(UISwitch *)sw{
    NSUInteger index = (NSUInteger) sw.tag;
    MASConstraint *width = _widthConstraints[index];
    
    if (sw.on) {
        width.equalTo(@(IMAGE_SIZE));
    } else {
        width.equalTo(@0);
    }
}


@end
