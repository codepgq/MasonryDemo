//
//  Case12ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case12ViewController.h"



@interface Case12ViewController ()

@property (nonatomic,strong) UILabel * titleLab;
@property (nonatomic,strong) UIButton * startAnimate;
@property (nonatomic,strong) UIButton * tipButton;

@property (nonatomic,strong) MASConstraint * tipButtonCenterXCons;

@end

@implementation Case12ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
}

- (void)initUI{
    _titleLab = [UILabel new];
    _startAnimate = [UIButton new];
    _tipButton = [UIButton new];
    
    [self addViews:@[_tipButton,_titleLab,_startAnimate] father:self.view];
    
    [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view.mas_centerX);
        make.top.equalTo(self.mas_topLayoutGuide).offset(10);
    }];
    
    [_tipButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.view.mas_centerY);
        _tipButtonCenterXCons = make.centerX.equalTo(self.view.mas_centerX);
        make.width.height.mas_equalTo(CGSizeMake(200, 44));
    }];
    
    [_startAnimate mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view.mas_centerX);
        make.bottom.equalTo(self.view.mas_bottom).offset(-20);
    }];
    
    _titleLab.numberOfLines = 0;
    _titleLab.textAlignment = NSTextAlignmentCenter;
    _titleLab.text = @"利用layoutIfNeeded\n控制约束生效时机";
    
    [_tipButton setTitle:@"我是动画来着的" forState:UIControlStateNormal];
    _tipButton.backgroundColor = [UIColor grayColor];
    _tipButton.userInteractionEnabled = NO;
    
    [_startAnimate setTitle:@"执行动画" forState:UIControlStateNormal];
    [_startAnimate setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [_startAnimate addTarget:self action:@selector(startAmiationEvent) forControlEvents:UIControlEventTouchUpInside];
    [_startAnimate sizeToFit];
    
}

- (void)startAmiationEvent{
    _tipButtonCenterXCons.offset(-SC_Width);
    [self.view layoutIfNeeded];
    
    _tipButtonCenterXCons.offset(0);
    
    [UIView animateWithDuration:0.35 animations:^{
        [self.view layoutIfNeeded];
    }];
}

@end
