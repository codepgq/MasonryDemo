//
//  Controller.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Controller.h"
#import <UIKit/UIKit.h>
@implementation Controller

+ (NSArray<Controller*>*)loadForPlist{
    NSMutableArray * mArr = [NSMutableArray array];
    
    NSArray * array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Controllers.plist" ofType:nil] ];
    
    for (NSDictionary * dict in array) {
        [mArr addObject:[Controller controllerWithDict:dict]];
    }
    
    return mArr;
}

+ (instancetype)controllerWithDict:(NSDictionary *)dict{
    Controller * controller = [[Controller alloc]init];
    
    [controller setValuesForKeysWithDictionary:dict];
    
    return controller;
}

- (UIViewController *)getPushController{
    Class cls = NSClassFromString([NSString stringWithFormat:@"%@ViewController",_text]);
    UIViewController * controller = [[cls alloc]init];
    
    
    if ([_text isEqualToString:@"Case5"]) {
        controller.tabBarController.tabBar.hidden = NO;
    }
    
    controller.title = self.title;
    return controller;
}

@end
