//
//  Case8.m
//  MasonryDemo
//
//  Created by Mac on 16/12/26.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case8.h"

@implementation Case8
+ (NSArray <Case8*>*)randomDataWithCount:(NSInteger)count{
    NSMutableArray <Case8*>* mArr = [NSMutableArray array];
    
    for (NSInteger i = 0; i<count; i++) {
        Case8 * c = [[self alloc]init];
        c.name = [NSString stringWithFormat:@"case^_^ :%zd",i];
        c.icon = @"emoitcon";
        c.descStr = [self randomContent];
        c.isShow = NO;
        c.index = i;
        [mArr addObject:c];
    }
    
    return mArr;
}

+ (NSString *)randomContent{
    NSMutableString * str = [NSMutableString string];
    int count = arc4random() % 20;
    for (int i= 0; i<count; i++) {
        [str appendString:@"content -"];
    }
    return str;
}

- (void)updateRowHeight:(float)rowHeight{
    self.rowHeight = rowHeight;
}
@end
