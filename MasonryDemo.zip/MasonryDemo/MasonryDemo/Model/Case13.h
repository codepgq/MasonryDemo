//
//  Case13.h
//  MasonryDemo
//
//  Created by Mac on 16/12/28.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Case13 : NSObject

@property (nonatomic,strong) NSString * left;
@property (nonatomic,strong) NSString * middle;
@property (nonatomic,strong) NSString * right;

+ (NSArray <Case13*>*)randomDataWithCount:(NSInteger)count;

@end
