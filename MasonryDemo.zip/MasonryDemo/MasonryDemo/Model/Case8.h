//
//  Case8.h
//  MasonryDemo
//
//  Created by Mac on 16/12/26.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Case8 : NSObject
@property (nonatomic,strong) NSString * icon;
@property (nonatomic,strong) NSString * name;
@property (nonatomic,strong) NSString * descStr;
@property (nonatomic,assign) BOOL isShow;
@property (nonatomic,assign) int index;

@property (nonatomic,assign) float rowHeight;

+ (NSArray <Case8*>*)randomDataWithCount:(NSInteger)count;

- (void)updateRowHeight:(float)rowHeight;


@end
