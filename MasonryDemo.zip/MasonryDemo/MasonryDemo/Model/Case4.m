//
//  Case4.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case4.h"

@implementation Case4

+ (NSArray <Case4*>*)randomDataWithCount:(NSInteger)count{
    NSMutableArray <Case4*>* mArr = [NSMutableArray array];
    
    for (NSInteger i = 0; i<count; i++) {
        Case4 * c = [[Case4 alloc]init];
        c.name = [NSString stringWithFormat:@"case^_^ :%zd",i];
        c.icon = @"emoitcon";
        c.descStr = [self randomContent];
        
        [mArr addObject:c];
    }
    
    return mArr;
}

+ (NSString *)randomContent{
    NSMutableString * str = [NSMutableString string];
    int count = arc4random() % 20;
    for (int i= 0; i<count; i++) {
        [str appendString:@"content -"];
    }
    return str;
}

- (void)updateRowHeight:(float)rowHeight{
    self.rowHeight = rowHeight;
}

@end
