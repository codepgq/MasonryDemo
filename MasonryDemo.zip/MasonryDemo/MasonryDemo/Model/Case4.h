//
//  Case4.h
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Case4 : NSObject
@property (nonatomic,strong) NSString * icon;
@property (nonatomic,strong) NSString * name;
@property (nonatomic,strong) NSString * descStr;

@property (nonatomic,assign) float rowHeight;

+ (NSArray <Case4*>*)randomDataWithCount:(NSInteger)count;

- (void)updateRowHeight:(float)rowHeight;

@end
