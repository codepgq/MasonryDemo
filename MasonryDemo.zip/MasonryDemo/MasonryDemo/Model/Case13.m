//
//  Case13.m
//  MasonryDemo
//
//  Created by Mac on 16/12/28.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case13.h"

@implementation Case13

+ (NSArray <Case13*>*)randomDataWithCount:(NSInteger)count{
    NSMutableArray <Case13*>* mArr = [NSMutableArray array];
    
    for (NSInteger i = 0; i<count; i++) {
        Case13 * c = [[Case13 alloc]init];
        c.left = [self randomContent];
        c.middle = [self randomContent];
        c.right = [self randomContent];
        
        [mArr addObject:c];
    }
    
    return mArr;
}

+ (NSString *)randomContent{
    NSMutableString * str = [NSMutableString string];
    int count = arc4random() % 20;
    for (int i= 0; i<count; i++) {
        [str appendString:@"case13_"];
    }
    return str;
}

@end
