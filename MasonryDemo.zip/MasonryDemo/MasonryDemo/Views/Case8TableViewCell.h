//
//  Case8TableViewCell.h
//  MasonryDemo
//
//  Created by Mac on 16/12/26.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Case8;

@interface Case8TableViewCell : UITableViewCell
@property (nonatomic,strong) UIImageView * icon;
@property (nonatomic,strong) UILabel * nameLab;
@property (nonatomic,strong) UILabel * descriptLab;
@property (nonatomic,strong) UIButton * showMore;

- (void)showMoreButton:(void(^)(UIButton * button,Case8 *case8))block;
- (void)updateCellWithCase4:(Case8 *)case8;
- (CGFloat)getRowHeightWithCase4:(Case8 *)case8;

@end



