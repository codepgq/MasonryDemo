//
//  Case4TableViewCell.h
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Case4.h"
@interface Case4TableViewCell : UITableViewCell
@property (nonatomic,strong) UIImageView * icon;
@property (nonatomic,strong) UILabel * nameLab;
@property (nonatomic,strong) UILabel * descriptLab;

- (void)updateCellWithCase4:(Case4 *)case4;
- (CGFloat)getRowHeightWithCase4:(Case4 *)case4;
@end
