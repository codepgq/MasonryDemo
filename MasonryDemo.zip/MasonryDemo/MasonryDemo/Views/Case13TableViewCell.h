//
//  Case13TableViewCell.h
//  MasonryDemo
//
//  Created by Mac on 16/12/28.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Case13;

@interface Case13TableViewCell : UITableViewCell


@property (nonatomic,strong) UILabel * leftLab;
@property (nonatomic,strong) UILabel * middleLab;
@property (nonatomic,strong) UILabel * rightLab;

- (void)setLabelWith:(Case13 *)case13;
@end
