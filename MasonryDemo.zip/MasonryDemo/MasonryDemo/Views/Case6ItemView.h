//
//  Case6ItemView.h
//  MasonryDemo
//
//  Created by Mac on 16/12/26.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Case6ItemView : UIView

+ (instancetype)itemWithImage:(UIImage *)image text:(NSString *)text;

@end
