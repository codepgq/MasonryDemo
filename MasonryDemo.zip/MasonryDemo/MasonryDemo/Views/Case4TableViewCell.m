//
//  Case4TableViewCell.m
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case4TableViewCell.h"
#import "Masonry.h"
@implementation Case4TableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (void)setupUI{
    //create
    self.nameLab = [UILabel new];
    self.icon = [UIImageView new];
    self.descriptLab = [UILabel new];
    
    //add
    [self.contentView addSubview:self.nameLab];
    [self.contentView addSubview:self.icon];
    [self.contentView addSubview:self.descriptLab];
    
    // add contrasint
    [self.icon mas_makeConstraints:^(MASConstraintMaker *make) {
//        //左边10个像素
//        make.left.equalTo(@10);
//        //上面10个像素
//        make.top.equalTo(@10);
        //大小固定
        make.width.height.equalTo(@40);
        
        make.left.top.equalTo(@10);
    }];
    
    [self.nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        //距离左边的图片10个像素
        make.left.equalTo(_icon.mas_right).offset(10);
        //高度和图片高度齐平
        make.top.equalTo(_icon.mas_top);
        //距离右边10个像素
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        //设置高度
        make.height.equalTo(@(20));
    }];

    [self.descriptLab mas_makeConstraints:^(MASConstraintMaker *make) {
//        //左边和name齐平
//        make.left.equalTo(_nameLab);
//        //距离上面的lalbe距离10个像素
//        make.top.equalTo(_nameLab.mas_bottom).offset(10);
//        //右边和name齐平
//        make.right.equalTo(_nameLab);
//        //底部和父视图一样
//        make.bottom.equalTo(self.contentView).with.offset(-4);
        make.left.right.equalTo(_nameLab);
        make.top.equalTo(_nameLab.mas_bottom).offset(5);
        make.bottom.equalTo(self.contentView.mas_bottom);
    }];
    
    [self.descriptLab setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    
    // set property
    self.descriptLab.numberOfLines = 0;
    CGFloat preferredMaxWidth = [UIScreen mainScreen].bounds.size.width - 10 - 40 - 10 - 10;
    self.descriptLab.preferredMaxLayoutWidth = preferredMaxWidth;
}

- (void)updateCellWithCase4:(Case4 *)case4{
    self.icon.image = [UIImage imageNamed:case4.icon];
    self.nameLab.text = case4.name;
    self.descriptLab.text = case4.descStr;
}

- (CGFloat)getRowHeightWithCase4:(Case4 *)case4{
    [self updateCellWithCase4:case4];
    CGFloat rowHeight = [self.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize].height + 0.5f;
    return rowHeight;
}

@end
