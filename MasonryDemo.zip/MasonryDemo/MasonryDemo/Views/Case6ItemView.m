//
//  Case6ItemView.m
//  MasonryDemo
//
//  Created by Mac on 16/12/26.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case6ItemView.h"
#import "Masonry.h"
@interface Case6ItemView ()
@property (nonatomic,strong) UIView * baseView;
@property (nonatomic,strong) UIImage * image;
@property (nonatomic,strong) NSString * text;

@end

@implementation Case6ItemView

+ (instancetype)itemWithImage:(UIImage *)image text:(NSString *)text{
    Case6ItemView * item = [Case6ItemView new];
    item.image = image;
    item.text = text;
    [item setupUI];
    return item;
}

- (void)setupUI{
    
    self.backgroundColor = [UIColor lightGrayColor];
    
    UIImageView * imgView = [[UIImageView alloc]initWithImage:self.image];
    self.baseView = imgView;
    
    //label
    UILabel * label = [UILabel new];
    label.numberOfLines = 0;
    label.text = _text;
    label.textColor = [UIColor whiteColor];
    
    [self addSubview:imgView];
    [self addSubview:label];
    
    [imgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.equalTo(self).with.offset(4);
        make.right.equalTo(self).with.offset(-4);
    }];
    
    //设置图片不跟随父控件变大儿变大
    [imgView setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [imgView setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    
    //label
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(imgView);
        make.top.equalTo(imgView.mas_bottom).offset(5);
        make.bottom.equalTo(self);
    }];
    [label setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    
}

- (UIView *)viewForBaselineLayout{
    return _baseView;
}

@end
