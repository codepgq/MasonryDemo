//
//  Case13TableViewCell.m
//  MasonryDemo
//
//  Created by Mac on 16/12/28.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Case13TableViewCell.h"
#import "Case13.h"
#import "Masonry.h"

@interface Case13TableViewCell ()

@property (nonatomic,strong) MASConstraint * marginContrasint;

@end

@implementation Case13TableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (void)setupUI{
    //create
    _leftLab = [self createLabel];
    _rightLab = [self createLabel];
    _middleLab = [self createLabel];
    
    //add
    [self.contentView addSubview:_leftLab];
    [self.contentView addSubview:_rightLab];
    [self.contentView addSubview:_middleLab];
    
    [_leftLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@100);
        make.left.equalTo(self.contentView.mas_leftMargin);
        _marginContrasint = make.top.equalTo(self.contentView.mas_topMargin);
        make.bottom.lessThanOrEqualTo(self.contentView.mas_bottomMargin);
    }];
    
    [_middleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@100);
        make.centerX.equalTo(self.contentView.mas_centerX);
        make.top.equalTo(self.contentView.mas_topMargin);
        make.bottom.lessThanOrEqualTo(self.contentView.mas_bottomMargin);
    }];

    [_rightLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@100);
        make.right.equalTo(self.contentView.mas_rightMargin);
        make.top.equalTo(self.contentView.mas_topMargin);
        make.bottom.lessThanOrEqualTo(self.contentView.mas_bottomMargin);
    }];
    
    NSLog(@"%@",_marginContrasint);
}

- (void)setLabelWith:(Case13 *)case13{
    
    _leftLab.text = case13.left;
    _middleLab.text = case13.middle;
    _rightLab.text = case13.right;
}


- (UILabel *)createLabel{
    UILabel * lab = [UILabel new];
    
    lab.layer.borderColor = [UIColor grayColor].CGColor;
    lab.layer.borderWidth = 2;
    lab.font = [UIFont systemFontOfSize:14];
    lab.numberOfLines = 0;
    
    return lab;
}
@end
