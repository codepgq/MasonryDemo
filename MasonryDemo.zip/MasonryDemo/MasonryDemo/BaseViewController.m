//
//  BaseViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/12/22.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    self.view.backgroundColor = [UIColor whiteColor];
}

- (UILabel *)getNewLabel{
    UILabel * label = [[UILabel alloc]init];
    return label;
}

- (UIView *)getNewView{
    return [[UIView alloc]init];
}

- (UIStepper *)getNewStepper{
    return [[UIStepper alloc]init];
}

- (UIButton *)getNewButton{
    return [[UIButton alloc]init];
}

- (void)addViews:(NSArray<UIView*>*)all father:(UIView *)view{
    for (UIView * subView in all) {
        [view addSubview:subView];
    }
}
@end
