//
//  ViewController.m
//  MasonryDemo
//
//  Created by Mac on 16/11/3.
//  Copyright © 2016年 Mac. All rights reserved.
//

//http://tutuge.me/2015/05/23/autolayout-example-with-masonry/
#import "ViewController.h"
#import "Controller.h"
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) NSArray<Controller*>* allControllers;
@end

static NSString * const CellIdentifier = @"CellIdentifier";

@implementation ViewController

- (NSArray<Controller *> *)allControllers{
    if (!_allControllers) {
        _allControllers = [Controller loadForPlist];
    }
    return _allControllers;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.allControllers.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    cell.textLabel.text = self.allControllers[indexPath.row].text;
    cell.detailTextLabel.text = self.allControllers[indexPath.row].title;
    cell.detailTextLabel.adjustsFontSizeToFitWidth = YES;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UIViewController * controller = [self.allControllers[indexPath.row] getPushController];
    [self.navigationController pushViewController:controller animated:YES];
}



@end
