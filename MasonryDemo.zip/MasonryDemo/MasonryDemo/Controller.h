//
//  Controller.h
//  MasonryDemo
//
//  Created by Mac on 16/12/24.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>
@class UIViewController;
@interface Controller : NSObject

@property (nonatomic,strong) NSString * title;
@property (nonatomic,strong) NSString * text;

+ (instancetype)controllerWithDict:(NSDictionary *)dict;

+ (NSArray<Controller*>*)loadForPlist;

- (UIViewController *)getPushController;
@end
