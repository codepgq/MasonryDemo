//
//  BaseViewController.h
//  MasonryDemo
//
//  Created by Mac on 16/12/22.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Masonry.h"
#define SC_Width [UIScreen mainScreen].bounds.size.width
#define SYSTEM_VERSION_8_0 [[[UIDevice currentDevice] systemVersion] floatValue] > 8.0
@interface BaseViewController : UIViewController

- (UILabel *)getNewLabel;
- (UIView *)getNewView;
- (UIStepper *)getNewStepper;
- (UIButton *)getNewButton;
- (void)addViews:(NSArray<UIView*>*)all father:(UIView *)view;
@end
